import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/employee.dart';
import '../models/attendance_record.dart';

class StorageService {
  static const String _employeesKey = 'employees';
  static const String _recordsKey = 'attendance_records';
  static const String _settingsKey = 'app_settings';
  static final _uuid = Uuid();

  // ─── Employees ───────────────────────────────────────────────

  static Future<List<Employee>> getEmployees() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList(_employeesKey) ?? [];
    return data.map((e) => Employee.fromJson(e)).toList();
  }

  static Future<void> saveEmployee(Employee employee) async {
    final prefs = await SharedPreferences.getInstance();
    final employees = await getEmployees();
    final idx = employees.indexWhere((e) => e.id == employee.id);
    if (idx >= 0) {
      employees[idx] = employee;
    } else {
      employees.add(employee);
    }
    await prefs.setStringList(
      _employeesKey,
      employees.map((e) => e.toJson()).toList(),
    );
  }

  static Future<void> deleteEmployee(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final employees = await getEmployees();
    employees.removeWhere((e) => e.id == id);
    await prefs.setStringList(
      _employeesKey,
      employees.map((e) => e.toJson()).toList(),
    );
  }

  static Future<Employee?> getEmployeeByPin(String pin) async {
    final employees = await getEmployees();
    try {
      return employees.firstWhere((e) => e.pin == pin);
    } catch (_) {
      return null;
    }
  }

  static Future<bool> isFirstRun() async {
    final employees = await getEmployees();
    return employees.isEmpty;
  }

  static Future<void> createDefaultAdmin() async {
    final admin = Employee(
      id: _uuid.v4(),
      name: 'المدير',
      department: 'الإدارة',
      position: 'مدير عام',
      phone: '',
      pin: '0000',
      isAdmin: true,
      createdAt: DateTime.now(),
    );
    await saveEmployee(admin);
  }

  // ─── Attendance Records ───────────────────────────────────────

  static Future<List<AttendanceRecord>> getAllRecords() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList(_recordsKey) ?? [];
    return data.map((e) => AttendanceRecord.fromJson(e)).toList();
  }

  static Future<List<AttendanceRecord>> getEmployeeRecords(
      String employeeId) async {
    final all = await getAllRecords();
    return all.where((r) => r.employeeId == employeeId).toList()
      ..sort((a, b) => b.checkIn.compareTo(a.checkIn));
  }

  static Future<AttendanceRecord?> getTodayRecord(String employeeId) async {
    final all = await getAllRecords();
    final today = DateTime.now();
    try {
      return all.firstWhere(
        (r) =>
            r.employeeId == employeeId &&
            r.checkIn.year == today.year &&
            r.checkIn.month == today.month &&
            r.checkIn.day == today.day,
      );
    } catch (_) {
      return null;
    }
  }

  static Future<AttendanceRecord> checkIn({
    required String employeeId,
    required double lat,
    required double lng,
    required String address,
  }) async {
    final record = AttendanceRecord(
      id: _uuid.v4(),
      employeeId: employeeId,
      checkIn: DateTime.now(),
      checkInLat: lat,
      checkInLng: lng,
      checkInAddress: address,
      status: _determineStatus(DateTime.now()),
    );
    await _saveRecord(record);
    return record;
  }

  static Future<AttendanceRecord> checkOut({
    required String recordId,
    required double lat,
    required double lng,
    required String address,
  }) async {
    final all = await getAllRecords();
    final idx = all.indexWhere((r) => r.id == recordId);
    if (idx < 0) throw Exception('Record not found');

    all[idx].checkOut = DateTime.now();
    all[idx].checkOutLat = lat;
    all[idx].checkOutLng = lng;
    all[idx].checkOutAddress = address;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _recordsKey,
      all.map((e) => e.toJson()).toList(),
    );
    return all[idx];
  }

  static Future<void> _saveRecord(AttendanceRecord record) async {
    final prefs = await SharedPreferences.getInstance();
    final all = await getAllRecords();
    all.add(record);
    await prefs.setStringList(
      _recordsKey,
      all.map((e) => e.toJson()).toList(),
    );
  }

  static AttendanceStatus _determineStatus(DateTime time) {
    final workStart = DateTime(time.year, time.month, time.day, 9, 0);
    if (time.isAfter(workStart.add(Duration(minutes: 15)))) {
      return AttendanceStatus.late;
    }
    return AttendanceStatus.present;
  }

  // ─── Statistics ───────────────────────────────────────────────

  static Future<Map<String, dynamic>> getMonthlyStats(
      String employeeId, int year, int month) async {
    final all = await getEmployeeRecords(employeeId);
    final monthRecords = all
        .where((r) => r.checkIn.year == year && r.checkIn.month == month)
        .toList();

    final present = monthRecords
        .where((r) => r.status == AttendanceStatus.present)
        .length;
    final late =
        monthRecords.where((r) => r.status == AttendanceStatus.late).length;
    final totalMinutes =
        monthRecords.where((r) => r.duration != null).fold<int>(
              0,
              (sum, r) => sum + r.duration!.inMinutes,
            );

    return {
      'total': monthRecords.length,
      'present': present,
      'late': late,
      'totalHours': (totalMinutes / 60).toStringAsFixed(1),
      'avgHours': monthRecords.isEmpty
          ? '0'
          : (totalMinutes / 60 / monthRecords.length).toStringAsFixed(1),
    };
  }

  // ─── Settings ─────────────────────────────────────────────────

  static Future<Map<String, dynamic>> getSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_settingsKey);
    if (data == null) {
      return {
        'companyName': 'شركتي',
        'workStartHour': 9,
        'workStartMinute': 0,
        'workEndHour': 17,
        'workEndMinute': 0,
        'lateToleranceMinutes': 15,
      };
    }
    return jsonDecode(data);
  }

  static Future<void> saveSettings(Map<String, dynamic> settings) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_settingsKey, jsonEncode(settings));
  }
}
