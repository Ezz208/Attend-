import 'dart:convert';

enum AttendanceStatus { present, late, earlyLeave, absent }

class AttendanceRecord {
  final String id;
  final String employeeId;
  final DateTime checkIn;
  DateTime? checkOut;
  final double? checkInLat;
  final double? checkInLng;
  double? checkOutLat;
  double? checkOutLng;
  final String? checkInAddress;
  String? checkOutAddress;
  AttendanceStatus status;
  String? notes;

  AttendanceRecord({
    required this.id,
    required this.employeeId,
    required this.checkIn,
    this.checkOut,
    this.checkInLat,
    this.checkInLng,
    this.checkOutLat,
    this.checkOutLng,
    this.checkInAddress,
    this.checkOutAddress,
    required this.status,
    this.notes,
  });

  Duration? get duration {
    if (checkOut == null) return null;
    return checkOut!.difference(checkIn);
  }

  String get durationFormatted {
    if (duration == null) return 'لم ينصرف بعد';
    final h = duration!.inHours;
    final m = duration!.inMinutes.remainder(60);
    return '${h}س ${m}د';
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'employeeId': employeeId,
      'checkIn': checkIn.toIso8601String(),
      'checkOut': checkOut?.toIso8601String(),
      'checkInLat': checkInLat,
      'checkInLng': checkInLng,
      'checkOutLat': checkOutLat,
      'checkOutLng': checkOutLng,
      'checkInAddress': checkInAddress,
      'checkOutAddress': checkOutAddress,
      'status': status.index,
      'notes': notes,
    };
  }

  factory AttendanceRecord.fromMap(Map<String, dynamic> map) {
    return AttendanceRecord(
      id: map['id'],
      employeeId: map['employeeId'],
      checkIn: DateTime.parse(map['checkIn']),
      checkOut:
          map['checkOut'] != null ? DateTime.parse(map['checkOut']) : null,
      checkInLat: map['checkInLat']?.toDouble(),
      checkInLng: map['checkInLng']?.toDouble(),
      checkOutLat: map['checkOutLat']?.toDouble(),
      checkOutLng: map['checkOutLng']?.toDouble(),
      checkInAddress: map['checkInAddress'],
      checkOutAddress: map['checkOutAddress'],
      status: AttendanceStatus.values[map['status']],
      notes: map['notes'],
    );
  }

  String toJson() => jsonEncode(toMap());
  factory AttendanceRecord.fromJson(String source) =>
      AttendanceRecord.fromMap(jsonDecode(source));
}
