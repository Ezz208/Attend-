import 'dart:convert';

class Employee {
  final String id;
  final String name;
  final String department;
  final String position;
  final String phone;
  final String pin;
  final bool isAdmin;
  final DateTime createdAt;

  Employee({
    required this.id,
    required this.name,
    required this.department,
    required this.position,
    required this.phone,
    required this.pin,
    this.isAdmin = false,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'department': department,
      'position': position,
      'phone': phone,
      'pin': pin,
      'isAdmin': isAdmin,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory Employee.fromMap(Map<String, dynamic> map) {
    return Employee(
      id: map['id'],
      name: map['name'],
      department: map['department'],
      position: map['position'],
      phone: map['phone'] ?? '',
      pin: map['pin'],
      isAdmin: map['isAdmin'] ?? false,
      createdAt: DateTime.parse(map['createdAt']),
    );
  }

  String toJson() => jsonEncode(toMap());
  factory Employee.fromJson(String source) =>
      Employee.fromMap(jsonDecode(source));
}
