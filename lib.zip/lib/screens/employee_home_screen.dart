import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../models/employee.dart';
import '../models/attendance_record.dart';
import '../services/storage_service.dart';
import '../services/location_service.dart';
import '../theme.dart';
import 'login_screen.dart';
import 'employee_history_screen.dart';

class EmployeeHomeScreen extends StatefulWidget {
  final Employee employee;
  const EmployeeHomeScreen({super.key, required this.employee});

  @override
  State<EmployeeHomeScreen> createState() => _EmployeeHomeScreenState();
}

class _EmployeeHomeScreenState extends State<EmployeeHomeScreen> {
  AttendanceRecord? _todayRecord;
  bool _isLoading = false;
  late Stream<DateTime> _timeStream;

  @override
  void initState() {
    super.initState();
    _loadTodayRecord();
    _timeStream = Stream.periodic(Duration(seconds: 1), (_) => DateTime.now());
  }

  Future<void> _loadTodayRecord() async {
    final record = await StorageService.getTodayRecord(widget.employee.id);
    setState(() => _todayRecord = record);
  }

  Future<void> _handleCheckIn() async {
    setState(() => _isLoading = true);
    try {
      final pos = await LocationService.getCurrentPosition();
      if (pos == null) {
        _showError('تعذّر الحصول على الموقع. تأكد من تفعيل GPS.');
        return;
      }
      final address = LocationService.formatAddress(pos.latitude, pos.longitude);
      final record = await StorageService.checkIn(
        employeeId: widget.employee.id,
        lat: pos.latitude,
        lng: pos.longitude,
        address: address,
      );
      setState(() => _todayRecord = record);
      _showSuccess('تم تسجيل الحضور بنجاح ✅');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _handleCheckOut() async {
    if (_todayRecord == null) return;
    setState(() => _isLoading = true);
    try {
      final pos = await LocationService.getCurrentPosition();
      if (pos == null) {
        _showError('تعذّر الحصول على الموقع. تأكد من تفعيل GPS.');
        return;
      }
      final address = LocationService.formatAddress(pos.latitude, pos.longitude);
      final record = await StorageService.checkOut(
        recordId: _todayRecord!.id,
        lat: pos.latitude,
        lng: pos.longitude,
        address: address,
      );
      setState(() => _todayRecord = record);
      _showSuccess('تم تسجيل الانصراف بنجاح 👋');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: AppTheme.accent),
    );
  }

  void _showSuccess(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: AppTheme.secondary),
    );
  }

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('EEEE, d MMMM yyyy', 'ar');
    final tf = DateFormat('HH:mm:ss');

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Column(
        children: [
          // Header
          Container(
            padding: EdgeInsets.fromLTRB(20, 50, 20, 30),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppTheme.primary, Color(0xFF2980B9)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(32),
                bottomRight: Radius.circular(32),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('أهلاً،', style: TextStyle(color: Colors.white70, fontSize: 14)),
                        Text(
                          widget.employee.name,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          '${widget.employee.position} • ${widget.employee.department}',
                          style: TextStyle(color: Colors.white60, fontSize: 12),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    EmployeeHistoryScreen(employee: widget.employee),
                              ),
                            );
                          },
                          icon: Icon(Icons.history, color: Colors.white),
                        ),
                        IconButton(
                          onPressed: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (_) => LoginScreen()),
                            );
                          },
                          icon: Icon(Icons.logout, color: Colors.white),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 20),

                // Live clock
                Center(
                  child: StreamBuilder<DateTime>(
                    stream: _timeStream,
                    builder: (ctx, snap) {
                      final now = snap.data ?? DateTime.now();
                      return Column(
                        children: [
                          Text(
                            tf.format(now),
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 42,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 4,
                              fontFeatures: [FontFeature.tabularFigures()],
                            ),
                          ),
                          Text(
                            df.format(now),
                            style: TextStyle(color: Colors.white70, fontSize: 14),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  SizedBox(height: 8),
                  _buildStatusCard(),
                  SizedBox(height: 20),
                  _buildActionButton(),
                  SizedBox(height: 20),
                  if (_todayRecord != null) _buildTodayDetails(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCard() {
    final hasCheckedIn = _todayRecord != null;
    final hasCheckedOut = _todayRecord?.checkOut != null;

    Color statusColor;
    String statusText;
    IconData statusIcon;

    if (!hasCheckedIn) {
      statusColor = AppTheme.textLight;
      statusText = 'لم تسجل حضورك اليوم بعد';
      statusIcon = Icons.schedule;
    } else if (!hasCheckedOut) {
      statusColor = AppTheme.secondary;
      statusText = 'أنت في العمل الآن';
      statusIcon = Icons.work;
    } else {
      statusColor = AppTheme.primary;
      statusText = 'انتهى يوم عملك';
      statusIcon = Icons.home;
    }

    return Card(
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(statusIcon, color: statusColor, size: 24),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('الحالة', style: TextStyle(color: AppTheme.textLight, fontSize: 12)),
                  Text(
                    statusText,
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ).animate().fadeIn().slideY(begin: 0.2);
  }

  Widget _buildActionButton() {
    final hasCheckedIn = _todayRecord != null;
    final hasCheckedOut = _todayRecord?.checkOut != null;
    final isComplete = hasCheckedIn && hasCheckedOut;

    if (isComplete) {
      return Container(
        padding: EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppTheme.primary.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Icon(Icons.check_circle, color: AppTheme.primary, size: 48),
            SizedBox(height: 8),
            Text(
              'أتممت يوم عملك بنجاح! 🎉',
              style: TextStyle(
                color: AppTheme.primary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ).animate().scale(curve: Curves.elasticOut);
    }

    return GestureDetector(
      onTap: _isLoading ? null : (hasCheckedIn ? _handleCheckOut : _handleCheckIn),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        width: double.infinity,
        padding: EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: hasCheckedIn
                ? [Color(0xFFE74C3C), Color(0xFFC0392B)]
                : [AppTheme.secondary, Color(0xFF27AE60)],
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: (hasCheckedIn ? AppTheme.accent : AppTheme.secondary)
                  .withOpacity(0.4),
              blurRadius: 20,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            if (_isLoading)
              CircularProgressIndicator(color: Colors.white, strokeWidth: 3)
            else ...[
              Icon(
                hasCheckedIn ? Icons.logout : Icons.login,
                color: Colors.white,
                size: 48,
              ),
              SizedBox(height: 8),
              Text(
                hasCheckedIn ? 'تسجيل الانصراف' : 'تسجيل الحضور',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'اضغط لتسجيل ${hasCheckedIn ? "الانصراف" : "الحضور"} بالموقع الجغرافي',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
            ],
          ],
        ),
      ),
    ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.3);
  }

  Widget _buildTodayDetails() {
    final tf = DateFormat('HH:mm');
    return Card(
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'تفاصيل اليوم',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: AppTheme.textDark),
            ),
            SizedBox(height: 16),
            _DetailRow(
              icon: Icons.login,
              color: AppTheme.secondary,
              label: 'وقت الحضور',
              value: tf.format(_todayRecord!.checkIn),
            ),
            if (_todayRecord!.checkOut != null) ...[
              Divider(height: 20),
              _DetailRow(
                icon: Icons.logout,
                color: AppTheme.accent,
                label: 'وقت الانصراف',
                value: tf.format(_todayRecord!.checkOut!),
              ),
              Divider(height: 20),
              _DetailRow(
                icon: Icons.timer,
                color: AppTheme.primary,
                label: 'ساعات العمل',
                value: _todayRecord!.durationFormatted,
              ),
            ],
            if (_todayRecord!.status == AttendanceStatus.late) ...[
              Divider(height: 20),
              _DetailRow(
                icon: Icons.warning,
                color: AppTheme.warning,
                label: 'الحالة',
                value: '⚠️ متأخر',
              ),
            ],
            if (_todayRecord!.checkInAddress != null) ...[
              Divider(height: 20),
              _DetailRow(
                icon: Icons.location_on,
                color: Colors.blueGrey,
                label: 'الموقع',
                value: _todayRecord!.checkInAddress!,
              ),
            ],
          ],
        ),
      ),
    ).animate().fadeIn(delay: 400.ms);
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final String value;

  const _DetailRow({
    required this.icon,
    required this.color,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: color, size: 20),
        SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: TextStyle(color: AppTheme.textLight, fontSize: 12)),
              Text(value,
                  style: TextStyle(
                      color: AppTheme.textDark,
                      fontWeight: FontWeight.w600,
                      fontSize: 14)),
            ],
          ),
        ),
      ],
    );
  }
}
