import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/employee.dart';
import '../models/attendance_record.dart';
import '../services/storage_service.dart';
import '../theme.dart';

class EmployeeHistoryScreen extends StatefulWidget {
  final Employee employee;
  const EmployeeHistoryScreen({super.key, required this.employee});

  @override
  State<EmployeeHistoryScreen> createState() => _EmployeeHistoryScreenState();
}

class _EmployeeHistoryScreenState extends State<EmployeeHistoryScreen> {
  List<AttendanceRecord> _records = [];
  Map<String, dynamic> _stats = {};
  bool _isLoading = true;
  final _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final records = await StorageService.getEmployeeRecords(widget.employee.id);
    final stats = await StorageService.getMonthlyStats(
        widget.employee.id, _now.year, _now.month);
    setState(() {
      _records = records;
      _stats = stats;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('سجل ${widget.employee.name}')),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
              children: [
                _buildStatsRow(),
                Expanded(
                  child: _records.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.inbox, size: 64, color: AppTheme.textLight),
                              SizedBox(height: 12),
                              Text('لا يوجد سجلات بعد',
                                  style: TextStyle(color: AppTheme.textLight)),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: EdgeInsets.all(16),
                          itemCount: _records.length,
                          itemBuilder: (_, i) => _RecordCard(record: _records[i]),
                        ),
                ),
              ],
            ),
    );
  }

  Widget _buildStatsRow() {
    return Container(
      color: AppTheme.primary,
      padding: EdgeInsets.all(16),
      child: Row(
        children: [
          _StatChip(label: 'أيام الشهر', value: '${_stats['total'] ?? 0}'),
          _StatChip(label: 'حاضر', value: '${_stats['present'] ?? 0}'),
          _StatChip(label: 'متأخر', value: '${_stats['late'] ?? 0}'),
          _StatChip(label: 'ساعات', value: '${_stats['totalHours'] ?? 0}'),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  const _StatChip({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(value,
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold)),
          Text(label,
              style: TextStyle(color: Colors.white70, fontSize: 11)),
        ],
      ),
    );
  }
}

class _RecordCard extends StatelessWidget {
  final AttendanceRecord record;
  const _RecordCard({required this.record});

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('EEEE d/M', 'ar');
    final tf = DateFormat('HH:mm');
    final isLate = record.status == AttendanceStatus.late;
    final hasCheckout = record.checkOut != null;

    return Card(
      margin: EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: isLate
                    ? AppTheme.warning.withOpacity(0.15)
                    : AppTheme.secondary.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(
                isLate ? Icons.warning_amber : Icons.check_circle,
                color: isLate ? AppTheme.warning : AppTheme.secondary,
                size: 22,
              ),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    df.format(record.checkIn),
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                  SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.login, size: 14, color: AppTheme.secondary),
                      SizedBox(width: 4),
                      Text(tf.format(record.checkIn),
                          style: TextStyle(fontSize: 13, color: AppTheme.textLight)),
                      SizedBox(width: 12),
                      if (hasCheckout) ...[
                        Icon(Icons.logout, size: 14, color: AppTheme.accent),
                        SizedBox(width: 4),
                        Text(tf.format(record.checkOut!),
                            style: TextStyle(fontSize: 13, color: AppTheme.textLight)),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  record.durationFormatted,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: AppTheme.primary,
                    fontSize: 13,
                  ),
                ),
                if (isLate)
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.warning.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      'متأخر',
                      style: TextStyle(color: AppTheme.warning, fontSize: 11),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
