import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/employee.dart';
import '../models/attendance_record.dart';
import '../services/storage_service.dart';
import '../theme.dart';
import 'login_screen.dart';
import 'add_employee_screen.dart';
import 'employee_history_screen.dart';

class AdminScreen extends StatefulWidget {
  final Employee admin;
  const AdminScreen({super.key, required this.admin});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  List<Employee> _employees = [];
  List<AttendanceRecord> _todayRecords = [];
  Map<String, dynamic> _settings = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
    _load();
  }

  Future<void> _load() async {
    final employees = await StorageService.getEmployees();
    final allRecords = await StorageService.getAllRecords();
    final settings = await StorageService.getSettings();
    final today = DateTime.now();
    final todayRecords = allRecords
        .where((r) =>
            r.checkIn.year == today.year &&
            r.checkIn.month == today.month &&
            r.checkIn.day == today.day)
        .toList();

    setState(() {
      _employees = employees.where((e) => !e.isAdmin).toList();
      _todayRecords = todayRecords;
      _settings = settings;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Column(
        children: [
          _buildHeader(),
          TabBar(
            controller: _tab,
            labelColor: AppTheme.primary,
            unselectedLabelColor: AppTheme.textLight,
            indicatorColor: AppTheme.primary,
            tabs: [
              Tab(text: 'اليوم', icon: Icon(Icons.today, size: 18)),
              Tab(text: 'الموظفون', icon: Icon(Icons.people, size: 18)),
              Tab(text: 'الإعدادات', icon: Icon(Icons.settings, size: 18)),
            ],
          ),
          Expanded(
            child: _isLoading
                ? Center(child: CircularProgressIndicator())
                : TabBarView(
                    controller: _tab,
                    children: [
                      _buildTodayTab(),
                      _buildEmployeesTab(),
                      _buildSettingsTab(),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.fromLTRB(20, 50, 20, 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.primary, Color(0xFF2980B9)],
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('لوحة الإدارة',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold)),
              Text(_settings['companyName'] ?? '',
                  style: TextStyle(color: Colors.white70, fontSize: 14)),
            ],
          ),
          IconButton(
            onPressed: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => LoginScreen()),
            ),
            icon: Icon(Icons.logout, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildTodayTab() {
    final checkedIn = _todayRecords.length;
    final total = _employees.length;
    final absent = total - checkedIn;
    final late = _todayRecords.where((r) => r.status == AttendanceStatus.late).length;

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: EdgeInsets.all(16),
        children: [
          // Summary cards
          Row(
            children: [
              _SummaryCard(
                  label: 'حاضر', value: '$checkedIn', color: AppTheme.secondary,
                  icon: Icons.check_circle),
              SizedBox(width: 12),
              _SummaryCard(
                  label: 'غائب', value: '$absent', color: AppTheme.accent,
                  icon: Icons.cancel),
            ],
          ),
          SizedBox(height: 12),
          Row(
            children: [
              _SummaryCard(
                  label: 'متأخر', value: '$late', color: AppTheme.warning,
                  icon: Icons.warning),
              SizedBox(width: 12),
              _SummaryCard(
                  label: 'إجمالي', value: '$total', color: AppTheme.primary,
                  icon: Icons.people),
            ],
          ),
          SizedBox(height: 20),
          Text('سجلات اليوم',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: AppTheme.textDark)),
          SizedBox(height: 12),
          if (_todayRecords.isEmpty)
            Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text('لا يوجد حضور مسجل اليوم',
                    style: TextStyle(color: AppTheme.textLight)),
              ),
            )
          else
            ..._todayRecords.map((r) {
              final emp = _employees.firstWhere(
                (e) => e.id == r.employeeId,
                orElse: () => Employee(
                  id: '', name: 'موظف', department: '', position: '',
                  phone: '', pin: '', createdAt: DateTime.now(),
                ),
              );
              return _TodayRecordCard(record: r, employee: emp);
            }),
        ],
      ),
    );
  }

  Widget _buildEmployeesTab() {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.all(16),
          child: ElevatedButton.icon(
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => AddEmployeeScreen()),
              );
              _load();
            },
            icon: Icon(Icons.person_add),
            label: Text('إضافة موظف جديد'),
            style: ElevatedButton.styleFrom(minimumSize: Size(double.infinity, 48)),
          ),
        ),
        Expanded(
          child: _employees.isEmpty
              ? Center(
                  child: Text('لا يوجد موظفون', style: TextStyle(color: AppTheme.textLight)),
                )
              : ListView.builder(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
                  itemCount: _employees.length,
                  itemBuilder: (_, i) {
                    final emp = _employees[i];
                    return Card(
                      margin: EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: AppTheme.primary.withOpacity(0.15),
                          child: Text(
                            emp.name.substring(0, 1),
                            style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.bold),
                          ),
                        ),
                        title: Text(emp.name, style: TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text('${emp.position} • ${emp.department}'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: Icon(Icons.history, color: AppTheme.primary),
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => EmployeeHistoryScreen(employee: emp),
                                ),
                              ),
                            ),
                            IconButton(
                              icon: Icon(Icons.delete_outline, color: AppTheme.accent),
                              onPressed: () => _confirmDelete(emp),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Future<void> _confirmDelete(Employee emp) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('حذف موظف'),
        content: Text('هل تريد حذف ${emp.name}؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text('حذف', style: TextStyle(color: AppTheme.accent))),
        ],
      ),
    );
    if (confirmed == true) {
      await StorageService.deleteEmployee(emp.id);
      _load();
    }
  }

  Widget _buildSettingsTab() {
    final nameController = TextEditingController(text: _settings['companyName']);
    return ListView(
      padding: EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('إعدادات الشركة',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                SizedBox(height: 16),
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(labelText: 'اسم الشركة'),
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () async {
                    _settings['companyName'] = nameController.text;
                    await StorageService.saveSettings(_settings);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('تم الحفظ ✅'), backgroundColor: AppTheme.secondary),
                    );
                  },
                  child: Text('حفظ الإعدادات'),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 12),
        Card(
          child: ListTile(
            leading: Icon(Icons.info_outline, color: AppTheme.primary),
            title: Text('رقم المدير السري'),
            subtitle: Text('0000 (يمكنك تغييره من إضافة موظف)'),
          ),
        ),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final IconData icon;

  const _SummaryCard({
    required this.label,
    required this.value,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(icon, color: color, size: 28),
              SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(value,
                      style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: color)),
                  Text(label,
                      style: TextStyle(color: AppTheme.textLight, fontSize: 12)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TodayRecordCard extends StatelessWidget {
  final AttendanceRecord record;
  final Employee employee;

  const _TodayRecordCard({required this.record, required this.employee});

  @override
  Widget build(BuildContext context) {
    final tf = DateFormat('HH:mm');
    final isLate = record.status == AttendanceStatus.late;

    return Card(
      margin: EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: isLate
                  ? AppTheme.warning.withOpacity(0.15)
                  : AppTheme.secondary.withOpacity(0.15),
              child: Text(
                employee.name.substring(0, 1),
                style: TextStyle(
                    color: isLate ? AppTheme.warning : AppTheme.secondary,
                    fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(employee.name,
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  Text(employee.department,
                      style: TextStyle(color: AppTheme.textLight, fontSize: 12)),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  children: [
                    Icon(Icons.login, size: 14, color: AppTheme.secondary),
                    SizedBox(width: 4),
                    Text(tf.format(record.checkIn),
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                  ],
                ),
                if (record.checkOut != null)
                  Row(
                    children: [
                      Icon(Icons.logout, size: 14, color: AppTheme.accent),
                      SizedBox(width: 4),
                      Text(tf.format(record.checkOut!),
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                    ],
                  )
                else
                  Text('لم ينصرف', style: TextStyle(color: AppTheme.textLight, fontSize: 11)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
