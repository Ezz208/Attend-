import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/employee.dart';
import '../services/storage_service.dart';
import '../theme.dart';

class AddEmployeeScreen extends StatefulWidget {
  const AddEmployeeScreen({super.key});

  @override
  State<AddEmployeeScreen> createState() => _AddEmployeeScreenState();
}

class _AddEmployeeScreenState extends State<AddEmployeeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _dept = TextEditingController();
  final _position = TextEditingController();
  final _phone = TextEditingController();
  final _pin = TextEditingController();
  bool _isAdmin = false;
  bool _isSaving = false;

  @override
  void dispose() {
    _name.dispose();
    _dept.dispose();
    _position.dispose();
    _phone.dispose();
    _pin.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    // Check PIN uniqueness
    final existing = await StorageService.getEmployeeByPin(_pin.text);
    if (existing != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('الرقم السري مستخدم بالفعل، اختر رقماً آخر'),
          backgroundColor: AppTheme.accent,
        ),
      );
      return;
    }

    setState(() => _isSaving = true);
    final employee = Employee(
      id: Uuid().v4(),
      name: _name.text.trim(),
      department: _dept.text.trim(),
      position: _position.text.trim(),
      phone: _phone.text.trim(),
      pin: _pin.text,
      isAdmin: _isAdmin,
      createdAt: DateTime.now(),
    );
    await StorageService.saveEmployee(employee);
    setState(() => _isSaving = false);

    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تم إضافة ${employee.name} بنجاح ✅'),
        backgroundColor: AppTheme.secondary,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إضافة موظف جديد')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(20),
          children: [
            _field(_name, 'الاسم الكامل', Icons.person, required: true),
            SizedBox(height: 16),
            _field(_dept, 'القسم', Icons.business, required: true),
            SizedBox(height: 16),
            _field(_position, 'المسمى الوظيفي', Icons.work, required: true),
            SizedBox(height: 16),
            _field(_phone, 'رقم الهاتف', Icons.phone, keyboardType: TextInputType.phone),
            SizedBox(height: 16),
            TextFormField(
              controller: _pin,
              keyboardType: TextInputType.number,
              maxLength: 4,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'الرقم السري (4 أرقام)',
                prefixIcon: Icon(Icons.lock),
                counterText: '',
              ),
              validator: (v) {
                if (v == null || v.isEmpty) return 'الرقم السري مطلوب';
                if (v.length != 4) return 'يجب أن يكون 4 أرقام بالضبط';
                if (!RegExp(r'^\d{4}$').hasMatch(v)) return 'أرقام فقط';
                return null;
              },
            ),
            SizedBox(height: 16),
            Card(
              child: SwitchListTile(
                title: Text('صلاحيات المدير'),
                subtitle: Text('المدير يمكنه رؤية لوحة التحكم'),
                value: _isAdmin,
                onChanged: (v) => setState(() => _isAdmin = v),
                activeColor: AppTheme.primary,
              ),
            ),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isSaving ? null : _save,
              child: _isSaving
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : Text('حفظ الموظف'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(
    TextEditingController ctrl,
    String label,
    IconData icon, {
    bool required = false,
    TextInputType? keyboardType,
  }) {
    return TextFormField(
      controller: ctrl,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
      ),
      validator: required
          ? (v) => (v == null || v.isEmpty) ? '$label مطلوب' : null
          : null,
    );
  }
}
